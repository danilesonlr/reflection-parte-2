package br.com.alura.alurator.playground.modelo;

public class SuperProduto {
	private int id;
}
